package com.domino.engine.core

/**
 * Set double-six: 28 kartu, indeks 0..27, disimpan sebagai bit di Int (bitmask).
 * Kartu (lo,hi) dengan lo <= hi punya indeks hi*(hi+1)/2 + lo.
 */
object Tiles {
    const val COUNT = 28
    val ALL: Int = (1 shl COUNT) - 1
    val LO = IntArray(COUNT)
    val HI = IntArray(COUNT)

    /** numberMask[n] = semua kartu yang memuat angka n. */
    val numberMask = IntArray(7)

    init {
        for (hi in 0..6) {
            for (lo in 0..hi) {
                val i = hi * (hi + 1) / 2 + lo
                LO[i] = lo
                HI[i] = hi
                numberMask[lo] = numberMask[lo] or (1 shl i)
                numberMask[hi] = numberMask[hi] or (1 shl i)
            }
        }
    }

    fun index(a: Int, b: Int): Int {
        val hi = if (a > b) a else b
        val lo = if (a > b) b else a
        return hi * (hi + 1) / 2 + lo
    }

    fun pips(t: Int): Int = LO[t] + HI[t]
    fun isDouble(t: Int): Boolean = LO[t] == HI[t]
    fun has(t: Int, n: Int): Boolean = LO[t] == n || HI[t] == n

    /** Angka di sisi lain kartu t kalau sisi n dipasang ke papan. */
    fun other(t: Int, n: Int): Int = if (LO[t] == n) HI[t] else LO[t]

    fun label(t: Int): String = "${LO[t]}-${HI[t]}"
}
