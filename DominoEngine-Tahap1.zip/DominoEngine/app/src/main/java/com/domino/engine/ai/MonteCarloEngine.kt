package com.domino.engine.ai

import com.domino.engine.core.GameState
import com.domino.engine.core.Move
import com.domino.engine.core.Rules
import com.domino.engine.core.Tiles
import java.util.SplittableRandom
import kotlin.math.max
import kotlin.math.sqrt

data class MoveEval(
    val move: Move,
    /** Perkiraan peluang menang (seri blok dibagi rata). */
    val winProb: Double,
    val stdErr: Double,
    /** Rata-rata sisa pip di tangan kita saat ronde simulasi berakhir (0 kalau menang). */
    val avgPips: Double
)

data class Analysis(
    /** Diurutkan dari yang terbaik. */
    val moves: List<MoveEval>,
    val samples: Int,
    val elapsedMs: Long,
    /** False kalau ada sampel yang terpaksa mengabaikan kendala pass. */
    val constraintsOk: Boolean,
    /** numberProb[0..2] = P2..P4; tiap isi 7 angka: peluang pemain itu memegang minimal 1 kartu bernomor n. */
    val numberProb: List<DoubleArray>,
    val done: Boolean
)

/**
 * Evaluasi langkah dengan Monte Carlo (determinization):
 * 1. ambil sampel kartu tersembunyi lawan (HiddenSampler),
 * 2. untuk TIAP langkah legal, mainkan sisa ronde dengan kebijakan heuristik sederhana untuk semua pemain,
 * 3. rata-ratakan hasilnya. Sampel yang sama dipakai untuk semua langkah supaya perbandingannya adil.
 *
 * Kebijakan simulasi (heuristik, bukan pemain sempurna): pilih kartu dengan nilai pip tinggi,
 * double diutamakan, ditambah sedikit acak.
 */
class MonteCarloEngine(seed: Long = System.nanoTime()) {
    private val rng = SplittableRandom(seed)
    private var outPips = 0

    fun analyze(
        state: GameState,
        budgetMs: Long,
        isCancelled: () -> Boolean,
        onProgress: (Analysis) -> Unit
    ) {
        val moves = Rules.legalMoves(state.myHand, state.left, state.right)
        if (moves.isEmpty()) {
            onProgress(Analysis(emptyList(), 0, 0, true, emptyList(), true))
            return
        }
        val sampler = HiddenSampler(state, rng)
        val m = moves.size
        val win = DoubleArray(m)
        val win2 = DoubleArray(m)
        val pip = DoubleArray(m)
        val has = Array(3) { IntArray(7) }
        val hands = IntArray(4)
        val work = IntArray(4)
        var n = 0
        var allOk = true
        val t0 = System.nanoTime()
        var lastReport = t0
        val budgetNs = budgetMs * 1_000_000L

        while (true) {
            if (isCancelled()) return
            val now = System.nanoTime()
            if (now - t0 >= budgetNs) break

            if (!sampler.sample(hands)) allOk = false
            hands[0] = state.myHand
            for (p in 1..3) {
                for (num in 0..6) {
                    if ((hands[p] and Tiles.numberMask[num]) != 0) has[p - 1][num]++
                }
            }

            for (i in 0 until m) {
                System.arraycopy(hands, 0, work, 0, 4)
                val mv = moves[i]
                work[0] = work[0] and (1 shl mv.tile).inv()
                val score: Double
                if (work[0] == 0) {
                    score = 1.0
                    outPips = 0
                } else {
                    val l = Rules.leftAfter(state.left, state.right, mv.tile, mv.side)
                    val r = Rules.rightAfter(state.left, state.right, mv.tile, mv.side)
                    score = rollout(work, l, r, 1, 0)
                }
                win[i] += score
                win2[i] += score * score
                pip[i] += outPips.toDouble()
            }
            n++

            if (now - lastReport > 200_000_000L) {
                lastReport = now
                onProgress(build(moves, win, win2, pip, has, n, t0, allOk, false))
            }
        }
        onProgress(build(moves, win, win2, pip, has, n, t0, allOk, true))
    }

    private fun build(
        moves: List<Move>,
        win: DoubleArray,
        win2: DoubleArray,
        pip: DoubleArray,
        has: Array<IntArray>,
        n: Int,
        t0: Long,
        ok: Boolean,
        done: Boolean
    ): Analysis {
        val evals = ArrayList<MoveEval>(moves.size)
        if (n > 0) {
            for (i in moves.indices) {
                val p = win[i] / n
                val variance = max(win2[i] / n - p * p, 0.0)
                evals.add(MoveEval(moves[i], p, sqrt(variance / n), pip[i] / n))
            }
            evals.sortWith(compareByDescending<MoveEval> { it.winProb }.thenBy { it.avgPips })
        } else {
            for (mv in moves) evals.add(MoveEval(mv, 0.0, 0.0, 0.0))
        }
        val probs = ArrayList<DoubleArray>(3)
        for (p in 0..2) {
            probs.add(DoubleArray(7) { num -> if (n > 0) has[p][num].toDouble() / n else 0.0 })
        }
        val ms = (System.nanoTime() - t0) / 1_000_000L
        return Analysis(evals, n, ms, ok, probs, done)
    }

    /** Memainkan sisa ronde. Mengembalikan skor kita (1 menang, 0 kalah, 1/k kalau seri blok). */
    private fun rollout(h: IntArray, l0: Int, r0: Int, turn0: Int, passes0: Int): Double {
        var l = l0
        var r = r0
        var turn = turn0
        var passes = passes0
        val lo = Tiles.LO
        val hi = Tiles.HI
        while (true) {
            val hand = h[turn]
            var bestT = -1
            var bestSide = 0
            var bestScore = -1
            var m = hand
            while (m != 0) {
                val t = Integer.numberOfTrailingZeros(m)
                m = m and (m - 1)
                val a = lo[t]
                val b = hi[t]
                val ml = a == l || b == l
                val mr = a == r || b == r
                if (!ml && !mr) continue
                val score = a + b + (if (a == b) 4 else 0) + rng.nextInt(6)
                if (score > bestScore) {
                    bestScore = score
                    bestT = t
                    bestSide = if (ml && mr) rng.nextInt(2) else if (ml) 0 else 1
                }
            }
            if (bestT < 0) {
                passes++
                if (passes >= 4) {
                    var minP = Int.MAX_VALUE
                    var cnt = 0
                    val p0 = Rules.pipSum(h[0])
                    for (i in 0..3) {
                        val p = Rules.pipSum(h[i])
                        if (p < minP) {
                            minP = p
                            cnt = 1
                        } else if (p == minP) {
                            cnt++
                        }
                    }
                    outPips = p0
                    return if (p0 == minP) 1.0 / cnt else 0.0
                }
                turn = (turn + 1) and 3
                continue
            }
            passes = 0
            h[turn] = hand and (1 shl bestT).inv()
            if (h[turn] == 0) {
                outPips = Rules.pipSum(h[0])
                return if (turn == 0) 1.0 else 0.0
            }
            if (bestSide == 0) l = Tiles.other(bestT, l) else r = Tiles.other(bestT, r)
            turn = (turn + 1) and 3
        }
    }
}
