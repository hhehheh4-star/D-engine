package com.domino.engine.ai

import com.domino.engine.core.GameState
import com.domino.engine.core.Tiles
import java.util.SplittableRandom

/**
 * Mengambil sampel pembagian kartu tersembunyi ke 3 lawan (P2, P3, P4).
 *
 * Setiap sampel menghormati:
 *  - 28 kartu unik: hanya kartu yang belum di papan dan bukan di tangan kita.
 *  - jumlah kartu tiap lawan (counts),
 *  - riwayat pass: pemain yang pass pada ujung (L,R) tidak punya kartu bernomor L atau R.
 *    Ujung yang dipakai adalah ujung SAAT pass itu terjadi (tersimpan di PassRecord), bukan ujung sekarang.
 *
 * Catatan jujur: pengambilan sampelnya greedy-acak dengan percobaan ulang, jadi distribusinya
 * mendekati seragam tetapi tidak dijamin seragam sempurna.
 */
class HiddenSampler(state: GameState, private val rng: SplittableRandom) {

    val unseen: IntArray
    private val allowedMask: IntArray
    private val allowedFree: IntArray
    private val need = IntArray(3)
    private val order: IntArray
    private val rem = IntArray(3)

    init {
        val u = state.unseen()
        val n = Integer.bitCount(u)
        unseen = IntArray(n)
        var m = u
        var k = 0
        while (m != 0) {
            val t = Integer.numberOfTrailingZeros(m)
            m = m and (m - 1)
            unseen[k] = t
            k++
        }

        // kartu terlarang per lawan, dari riwayat pass
        val forbid = IntArray(3)
        for (pr in state.passes) {
            if (pr.player in 1..3) {
                var f = 0
                if (pr.left >= 0) f = f or Tiles.numberMask[pr.left]
                if (pr.right >= 0) f = f or Tiles.numberMask[pr.right]
                forbid[pr.player - 1] = forbid[pr.player - 1] or f
            }
        }

        allowedMask = IntArray(n)
        allowedFree = IntArray(n) { 7 }
        for (i in 0 until n) {
            var a = 0
            for (p in 0..2) {
                if (((forbid[p] shr unseen[i]) and 1) == 0) a = a or (1 shl p)
            }
            allowedMask[i] = a
        }

        // jumlah kartu per lawan; kalau input tidak konsisten, sesuaikan agar total = jumlah kartu tak terlihat
        for (p in 0..2) need[p] = if (state.counts[p + 1] > 0) state.counts[p + 1] else 0
        var total = need[0] + need[1] + need[2]
        while (total > n) {
            var best = 0
            for (p in 1..2) if (need[p] > need[best]) best = p
            if (need[best] == 0) break
            need[best]--
            total--
        }
        while (total < n) {
            var best = 0
            for (p in 1..2) if (need[p] < need[best]) best = p
            need[best]++
            total++
        }
        order = IntArray(n) { it }
    }

    /** True kalau seluruh kendala pass terpenuhi; false kalau terpaksa mengabaikannya. */
    var lastRespectedConstraints: Boolean = true
        private set

    /** Mengisi out[1..3] dengan bitmask kartu P2..P4. out[0] tidak disentuh. */
    fun sample(out: IntArray): Boolean {
        var attempt = 0
        while (attempt < 40) {
            if (tryAssign(out, allowedMask)) {
                lastRespectedConstraints = true
                return true
            }
            attempt++
        }
        lastRespectedConstraints = false
        tryAssign(out, allowedFree)
        return false
    }

    private fun tryAssign(out: IntArray, allowed: IntArray): Boolean {
        val n = unseen.size
        // acak urutan
        for (i in n - 1 downTo 1) {
            val j = rng.nextInt(i + 1)
            val tmp = order[i]
            order[i] = order[j]
            order[j] = tmp
        }
        // urutkan stabil: kartu paling terbatas dulu
        for (i in 1 until n) {
            val v = order[i]
            val key = Integer.bitCount(allowed[v])
            var j = i - 1
            while (j >= 0 && Integer.bitCount(allowed[order[j]]) > key) {
                order[j + 1] = order[j]
                j--
            }
            order[j + 1] = v
        }
        rem[0] = need[0]
        rem[1] = need[1]
        rem[2] = need[2]
        out[1] = 0
        out[2] = 0
        out[3] = 0
        for (idx in 0 until n) {
            val i = order[idx]
            val a = allowed[i]
            var total = 0
            for (p in 0..2) if (((a shr p) and 1) == 1) total += rem[p]
            if (total == 0) return false
            var r = rng.nextInt(total)
            var chosen = -1
            for (p in 0..2) {
                if (((a shr p) and 1) == 1 && rem[p] > 0) {
                    if (r < rem[p]) {
                        chosen = p
                        break
                    }
                    r -= rem[p]
                }
            }
            rem[chosen]--
            out[chosen + 1] = out[chosen + 1] or (1 shl unseen[i])
        }
        return true
    }
}
