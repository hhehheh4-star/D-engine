package com.domino.engine.core

/**
 * Mengelola satu ronde yang diamati: input kartu, langkah, pass, giliran (searah jarum jam), undo.
 * Semua fungsi mengembalikan pesan error (String) kalau input tidak valid, atau null kalau sukses.
 */
class Session {
    var state: GameState = GameState()
        private set

    private val undoStack = ArrayDeque<GameState>()

    private fun commit(next: GameState) {
        undoStack.addLast(state)
        if (undoStack.size > 300) undoStack.removeFirst()
        state = next
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()

    fun undo(): Boolean {
        if (undoStack.isEmpty()) return false
        state = undoStack.removeLast()
        return true
    }

    fun newRound() {
        undoStack.clear()
        state = GameState()
    }

    fun toggleHandTile(t: Int): String? {
        val s = state
        if (s.phase != Phase.HAND_ENTRY) return "Bukan fase input kartu"
        val bit = 1 shl t
        val hand: Int
        if ((s.myHand and bit) != 0) {
            hand = s.myHand and bit.inv()
        } else {
            if (Integer.bitCount(s.myHand) >= 7) return "Sudah 7 kartu"
            hand = s.myHand or bit
        }
        val next = if (Integer.bitCount(hand) == 7) Phase.PICK_STARTER else Phase.HAND_ENTRY
        commit(s.copy(myHand = hand, phase = next))
        return null
    }

    fun setStarter(p: Int): String? {
        val s = state
        if (s.phase != Phase.PICK_STARTER) return "Bukan fase pilih pemain awal"
        if (p !in 0..3) return "Pemain tidak valid"
        commit(s.copy(phase = Phase.PLAYING, turn = p))
        return null
    }

    /** Koreksi manual giliran kalau tidak sinkron dengan game. */
    fun setTurn(p: Int): String? {
        val s = state
        if (s.phase != Phase.PLAYING) return "Ronde belum berjalan"
        if (p !in 0..3) return "Pemain tidak valid"
        commit(s.copy(turn = p))
        return null
    }

    /** Pemain yang sedang giliran (state.turn) memasang [tile] di [side]. */
    fun play(tile: Int, side: Side): String? {
        val s = state
        if (s.phase != Phase.PLAYING) return "Ronde belum berjalan"
        if (tile !in 0 until Tiles.COUNT) return "Kartu tidak valid"
        val bit = 1 shl tile
        if ((s.played and bit) != 0) return "Kartu ${Tiles.label(tile)} sudah keluar"
        val p = s.turn
        if (p == 0) {
            if ((s.myHand and bit) == 0) return "Kartu itu tidak ada di tangan lu"
        } else if ((s.myHand and bit) != 0) {
            return "Kartu itu ada di tangan lu"
        }
        if (s.counts[p] <= 0) return "Pemain ini sudah kehabisan kartu"
        if (s.boardEmpty) {
            if (side != Side.FIRST) return "Langkah pertama tidak punya sisi"
        } else {
            if (side == Side.FIRST || !Rules.fits(tile, side, s.left, s.right)) {
                return "Kartu tidak cocok dengan ujung papan"
            }
        }
        val nl = Rules.leftAfter(s.left, s.right, tile, side)
        val nr = Rules.rightAfter(s.left, s.right, tile, side)
        val newCounts = s.counts.toMutableList()
        newCounts[p] = newCounts[p] - 1
        val newHand = if (p == 0) (s.myHand and bit.inv()) else s.myHand
        val base = s.copy(
            played = s.played or bit,
            myHand = newHand,
            left = nl,
            right = nr,
            counts = newCounts,
            consecutivePasses = 0
        )
        if (newCounts[p] == 0) {
            commit(base.copy(phase = Phase.OVER, winner = p, endReason = EndReason.EMPTY_HAND))
        } else {
            commit(base.copy(turn = (p + 1) % 4))
        }
        return null
    }

    /** Pemain yang sedang giliran pass. Ujung papan SAAT INI dicatat bersama pass itu. */
    fun pass(): String? {
        val s = state
        if (s.phase != Phase.PLAYING) return "Ronde belum berjalan"
        if (s.boardEmpty) return "Tidak boleh pass di langkah pertama"
        if (s.turn == 0 && Rules.legalMoves(s.myHand, s.left, s.right).isNotEmpty()) {
            return "Lu masih punya kartu yang bisa jalan"
        }
        val rec = PassRecord(s.turn, s.left, s.right)
        val cp = s.consecutivePasses + 1
        val withPass = s.copy(passes = s.passes + rec, consecutivePasses = cp)
        if (cp >= 4) {
            commit(withPass.copy(phase = Phase.OVER, winner = -1, endReason = EndReason.BLOCKED))
        } else {
            commit(withPass.copy(turn = (s.turn + 1) % 4))
        }
        return null
    }
}
