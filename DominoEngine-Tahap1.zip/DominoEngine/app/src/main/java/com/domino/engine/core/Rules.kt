package com.domino.engine.core

object Rules {

    fun fits(tile: Int, side: Side, left: Int, right: Int): Boolean = when (side) {
        Side.FIRST -> left < 0
        Side.LEFT -> left >= 0 && Tiles.has(tile, left)
        Side.RIGHT -> right >= 0 && Tiles.has(tile, right)
    }

    /**
     * Semua langkah legal dari [hand]. Papan kosong => semua kartu boleh (Side.FIRST).
     * Kalau kedua ujung sama angkanya, sisi kiri/kanan setara, jadi hanya LEFT yang dicantumkan.
     */
    fun legalMoves(hand: Int, left: Int, right: Int): List<Move> {
        val out = ArrayList<Move>(14)
        var h = hand
        while (h != 0) {
            val t = Integer.numberOfTrailingZeros(h)
            h = h and (h - 1)
            if (left < 0) {
                out.add(Move(t, Side.FIRST))
                continue
            }
            val l = Tiles.has(t, left)
            val r = Tiles.has(t, right)
            if (l) out.add(Move(t, Side.LEFT))
            if (r && !(l && left == right)) out.add(Move(t, Side.RIGHT))
        }
        return out
    }

    fun leftAfter(left: Int, right: Int, tile: Int, side: Side): Int = when (side) {
        Side.FIRST -> Tiles.LO[tile]
        Side.LEFT -> Tiles.other(tile, left)
        Side.RIGHT -> left
    }

    fun rightAfter(left: Int, right: Int, tile: Int, side: Side): Int = when (side) {
        Side.FIRST -> Tiles.HI[tile]
        Side.LEFT -> right
        Side.RIGHT -> Tiles.other(tile, right)
    }

    fun pipSum(mask: Int): Int {
        var m = mask
        var s = 0
        while (m != 0) {
            val t = Integer.numberOfTrailingZeros(m)
            m = m and (m - 1)
            s += Tiles.pips(t)
        }
        return s
    }

    /** Permainan blok: pemenang = sisa pip terkecil. Kalau seri, SEMUA yang seri dikembalikan. */
    fun blockedWinners(pips: IntArray): List<Int> {
        var min = Int.MAX_VALUE
        for (p in pips) if (p < min) min = p
        val out = ArrayList<Int>()
        for (i in pips.indices) if (pips[i] == min) out.add(i)
        return out
    }
}
