# Domino Engine — Tahap 1

Overlay mengambang untuk petunjuk gaple (4 pemain, double-six, giliran searah jarum jam).
Android 8+ (target Android 11). Tidak menekan layar / bermain otomatis.

## Build lewat GitHub
1. Buat repo baru di GitHub, upload semua isi folder ini (termasuk folder `.github`).
2. Tab **Actions** -> workflow **Build APK** jalan otomatis (atau Run workflow).
3. Selesai -> buka run-nya -> **Artifacts** -> `DominoEngine-debug-apk` -> unduh, ekstrak, install `app-debug.apk`.

## Pasang & izin
1. Buka app -> "Izinkan tampil di atas aplikasi lain" -> aktifkan untuk Domino Engine.
2. "Aktifkan Aksesibilitas" -> cari Domino Engine -> aktifkan (sebagai cadangan overlay; dipakai screenshot di Tahap 2).
3. "Mulai Overlay" lalu buka game.

## Cara main
- Awal ronde: tap 7 kartu lu di grid, pilih siapa yang mulai.
- Giliran lawan: tap angka ujung baru -> tap panah kiri/kanan (atau PASS). Giliran pindah otomatis.
- Giliran lu: kartu terbaik muncul (hijau, ★). Mainkan di game, lalu tap kartu itu di panel.
- Header "Giliran: ..." bisa di-tap untuk koreksi giliran. UNDO untuk salah tap. ⟲ untuk reset ronde.

## Struktur
- core/  : Tiles, Rules, Session (aturan + state + undo), tanpa dependensi Android
- ai/    : HiddenSampler (inferensi lawan dari pass), MonteCarloEngine
- overlay/: OverlayController, OverlayService (foreground), DominoAccessibilityService
- ui/    : MainActivity
- test   : app/src/test (aturan, sampler, Monte Carlo)

## Belum ada (Tahap 2/3)
- Baca 7 kartu awal otomatis dari screenshot
- Deteksi pass otomatis dari badge jumlah kartu lawan
- Opasitas/ukuran overlay yang bisa diatur
